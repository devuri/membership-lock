<?php

# Lockdown Menu
$swlockdown_menu = array(
  'Membership Lockdown Settings',
  'Lockdown',
  'manage_options',
  'membeship-lockdown',
  'memlockdown_callback',
  '4.6',
  'dashicons-lock',
  'mls',
);

// initialize menu
new Si_Admin_Menu($swlockdown_menu);
